from src import config
from src import query_search
from src import dataset
from src import embeddings
from src import processing
from src import utils

import unittest

class Testing(unittest.TestCase):
    def test_query_search(self):
        assert True
    def test_dataset(self):
        assert True
    def test_embeddings(self):
        assert True
    def test_processing(self):
        assert True

if __name__ == "__main__":
    unittest.main()

