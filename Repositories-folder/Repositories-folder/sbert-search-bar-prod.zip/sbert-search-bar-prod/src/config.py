local_env = True
if local_env==True:
    DIR_ROOT = "."
else:
    DIR_ROOT = "/usr/src/app"
DIR_DATA = f"{DIR_ROOT}/data"
DIR_OUTPUT = f"{DIR_ROOT}/output"
NUM_OF_SEARCH_RESULTS = 10
